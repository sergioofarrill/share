<?php
/*
Template Name: Blog-Page
*/
?>

<?php get_template_part('templates/content', 'page'); ?>
