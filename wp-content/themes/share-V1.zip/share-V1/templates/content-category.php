
<?php get_template_part('templates/category', 'ideas'); ?>