<?php
/*
Template Name: theblog
*/
?>
<?php get_template_part('templates/content', 'page'); ?>